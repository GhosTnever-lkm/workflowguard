# Changelog

## 1.0.0 — 2026-10-08

- First public release of the offline GitHub Actions workflow scanner.
- Added eight checks for token permissions, untrusted pull request data, action refs, checkout credentials, and secret interpolation.
- Added text, JSON, and SARIF 2.1.0 output with configurable failure gates.
